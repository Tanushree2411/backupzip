#include<stdio.h>
#include<stdlib.h>
struct node
{
int value;
struct node *l;
struct node *r;
};

void preorder(struct node* root) {
  if (root == NULL) return;
  printf("%d ", root->value);
  preorder(root->l);
  preorder(root->r);
}
struct node *f_Node(int value)
{
struct node *new;
new = malloc(sizeof(struct node));
new->value = value;
new->l = NULL;
new->r = NULL;
return new;
}
struct node *insert(struct node *root, int value)
{
if(root == NULL)
return f_Node(value);
if(root->value < value)
root->r = insert(root->r,value);
else if(root->value > value)
root->l = insert(root->l,value);
return root;
}

int main()
{
struct node *root = NULL;
int temp_n;
int ele;
printf("total elements:");
scanf("%d",&ele);
for(int i =0;i<ele;i++)
{
    printf("enter number:");
    scanf("%d",&temp_n);
    root = insert(root,temp_n);
}
printf("preorder:\n");
preorder(root);

return 0;
}
 

