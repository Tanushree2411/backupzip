#include"Student.h"

int main(int argc, char *argv[]){
   Student s("Joe");
   s.display();
   return 0;
}
