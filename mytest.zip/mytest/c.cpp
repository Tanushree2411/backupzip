#include<iostream>
using namespace std;
int main()
{
int i;
cout<<"this is output\n";
cout<<"enyer number\n";
cin>>i;
cout<<i<<"squared is"<<i*i<<"\n";
return 0;
}

