#!/bin/bash
opt=$1
file=$2
shopt -s nocasematch
case $opt in
tar)
	echo "compressing $file for edit"
	;;
gzip)
	echo "zipping the content of $file"
;;
*)
	echo "args are missing"
;;
esac
