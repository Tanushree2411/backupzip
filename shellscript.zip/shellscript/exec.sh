file=/home/tanushree/output1.txt
exec 3<>$file
#exec 4< /etc/passwd
echo " this is first date wriiten to fd 3" >&3
date >&3
echo "displaying ip fd"
#cat <&4
echo "closing fds"
exec 3<&-
#exec 4<&-
