exec 2< log.txt
echo "fd #2">log.txt
exec 1< /home/tanushree/log.txt
#echo "data dread from fd2 to fd1"
exec 2<&-
exec 1< &-





