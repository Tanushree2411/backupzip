#!/bin/bash
Backpath=/home/tanushree
echo $Backpath
file=/etc/resolv.conf
echo "file is \$file"
read -p "enter value " n1 n2
echo "entered values is $n1 and $n2"
ans=$(($n1+$n2))
echo "ans is $ans"



