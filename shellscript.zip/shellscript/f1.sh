#use of funcname
backup()
{
local d=$1
[ ! -d $d ] && { echo "$funame(): dir isnot fouind";exit 1;}
#echo "exist"
}
#echo "exist"

backup $1
echo "backup started"


