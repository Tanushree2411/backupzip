#!/bin/bash
echo "hello chipmates"
