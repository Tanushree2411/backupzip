#!/bin/bash
# To zip the files and directories to other directory
user=$id
# path we want to store compress file

if [ user != 0 ]
then
	echo "please enter to root"
	exit 1
else
	echo "Contiune the process"
	find /usr/share/doc -type f \( -name "*.pdf" -o -name "*.txt" -o -name "*.html" \) > /home/tanushree/pro.txt
cat pro.txt
gzip -k pro.txt

	
	
fi
