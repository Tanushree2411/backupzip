file=/etc/passwd /etc/group /etc/shadow /etc/gshadow
user=$1
for user in $file
do
[ -f $user ] && echo "$user found" || echo "$user not found in $file"
done
