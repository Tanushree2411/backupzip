for command in date pwd df
do
	echo "welcome to command"
	$command
done
