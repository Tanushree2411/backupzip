
#this is script to user password
pass_file=/etc/passwd
read  -p "enter the uname" uname
grep "^$uname" $pass_file>/dev/null
status=$?
if test $status -eq 0
then 
	echo "user found"
else
	echo "not found"
fi
