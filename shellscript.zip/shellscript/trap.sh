trap 'echo "exiting on 0 signal detected"' 0
echo "test"
exit 0
