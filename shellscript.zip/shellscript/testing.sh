#!/bin/bash
cmd(){
echo "the name of script is $0"
echo "the first argument is $1"
echo "the 2nd argument is $2"
echo "total argumetns passed are $#"
echo "value of argumentd are $*"
echo "value of argumentd are $@"
}
echo "fun call"
cmd city
echo "giving csll 2nd time"
cmd city nexa kia
