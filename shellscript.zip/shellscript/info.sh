#!/bin/bash
#this script is to get network info.
echo "current date: $(date) hostname: $(hostname)"
echo "network info"
/sbin/iconfig
