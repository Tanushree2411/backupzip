for file in $(ls /home/tanushree/*.sh)
do
	echo "welcome to $file command"
	
done
