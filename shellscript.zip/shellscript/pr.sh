
for file in $( usr/share/doc -type f -name '*.html')
do
echo "Sfile"
done

