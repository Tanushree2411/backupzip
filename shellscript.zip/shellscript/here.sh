#here document
tar -cvf /home/tanushree/backup/b1.tar.gz  /home/tanushree/*.sh/ 2>/dev/null
[ $? -eq  0 ] && echo "backup done" || echo "backup failed"
status=$?
mail -s "backup ztatus" tanushreeshah24@gmail.com<<draft
date:$(date)
host:$(hostname)
status:$status
draft
