dest=/home/tanushree/backup
src=/home/tanushree
[!-d $dest] && mkdir -p $dest;
[! -d $src] && {echo "$src doestnit exist "exit 1;}
echo "Backing up i directory $dest"
tar zcvf $dest/backup.tar.gz $src 2>/dev/null 
