
#extract fileds from pwd
file=/etc/passwd
echo $IFS
while $IFS=: read -r user uid gid desc home shell 
do
[ $uid -ge 500 ] && echo "$user has $uid with home $home and shell $shell"
done < "$file"
