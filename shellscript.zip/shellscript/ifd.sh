exec 3< /etc/resolv.conf
exec 4> /home/tanushree/output1.txt
read -u 3 a b
mypid=$$
echo " cuurent opened file by $0 ARe "
ls -l /proc/$mypid/fd

#echo " data read from fd3 $a"
#echo " data read from fd3 $b"
#echo " writing back to fd4"
#echo "writing first field $a" >&4
#echo "2nd field $b" >&4
exec 3<&-
exec 4>&-
