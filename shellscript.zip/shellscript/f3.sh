#variable scope
scope() {
var=$1
echo "with in fun value of var is $var";
}
var=outside
echo "b4 calling fun value is $var"
scope local
echo "after call value of var is $var"


