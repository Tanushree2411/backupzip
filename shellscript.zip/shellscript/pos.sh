#this is script to user password
read  -p "enter the number" pass
if test "$pass" > 10
then 
	echo "positive"
else
	echo "negative"
fi
